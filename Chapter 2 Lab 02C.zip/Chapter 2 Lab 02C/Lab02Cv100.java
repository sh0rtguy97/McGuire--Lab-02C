// Lab02Cv100.java
// The 100-point version of Lab 02C is an exercise in precisely copying a
// provided program, followed by compiling the source code into bytecode
// and executing the bytecode file.

public class Lab02Cv100
{
	public static void main(String args[]) 
	{
		System.out.println("Lab 02C, 100 Point Version");
		System.out.println();
		System.out.println("First Java Program");
		System.out.println();
		System.out.println("Measure today's knowledge ");
		System.out.println("by yesterday's confusion.");
		System.out.println();
		System.out.println("Bewilderment + Exposure = Obvious");
		System.out.println();
		System.out.println("# ##### #####   ##### ##### # #   # ##### #####");
		System.out.println("# #   # #   #   #   # #   # # ##  #   #   #    ");
		System.out.println("# #   # #   #   ##### #   # # # # #   #   #####");
		System.out.println("# #   # #   #   #     #   # # #  ##   #       #");
		System.out.println("# ##### #####   #     ##### # #   #   #   #####");
	}
}



